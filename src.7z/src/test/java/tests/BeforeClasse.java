package tests;

public @interface BeforeClasse {

}
