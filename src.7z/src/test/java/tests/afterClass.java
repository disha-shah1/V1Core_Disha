package tests;

public @interface afterClass {

}
